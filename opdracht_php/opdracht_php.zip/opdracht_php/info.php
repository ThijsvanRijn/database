<?php
  ini_set('display_errors', 'On');
  phpinfo();
 ?>